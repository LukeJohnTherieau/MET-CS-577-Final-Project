- final_project.ipynb
	- Click "Run All" to get all final project results.
	- web_scraper.py will be run from the first cell using subprocess.

- web_scraper.py
	- multithreaded web scraper to extract the dataset.

- MET CS 577 Final Project.pptx
	- PowerPoint presentation that was presented in class and in video. 

- data
	- Folder that will be created via execution of web_scraper.py